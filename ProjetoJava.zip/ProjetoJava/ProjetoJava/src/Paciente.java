/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Carolina Ferraz
 */
public class Paciente {
    String Nome;
    String Sobrenome;
    int Idade;
    String Sexo;
    double Peso;
    int Altura;
    String Especialidade;
    String LocalDor;
    public Medico medico;
    
    public Paciente(){

    Nome = "-";
    Sobrenome = "-";
    Idade = 0;
    Peso = 0;
    Altura = 0;
    Especialidade = "-";
    LocalDor = "-";
    medico = null;
}
    
    
    
}
