
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aluno
 */
public class Arquivo {
    public void escreve(String linha,String arquivo) throws FileNotFoundException, IOException//metodo
    {
        //Arquivo txt
        OutputStream os = new FileOutputStream(arquivo+".txt",true);//procurando o arquivo
        OutputStreamWriter osw = new OutputStreamWriter(os);
        BufferedWriter bw = new BufferedWriter(osw);
        //Tratamento
        try
        {
            bw.write(linha+"\n_________________________________________\n");
            bw.close();
        }catch(FileNotFoundException ex){
            System.out.println("Erro durante a gravação");
            System.out.println(ex);
        }
       
    }

    
}
